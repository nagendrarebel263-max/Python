s=(18,7,2,14)
print(“Maximum Number : ”,max(s))

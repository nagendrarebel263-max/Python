df.replace({'name': {'James': 'Suresh'}}, inplace=True)
df

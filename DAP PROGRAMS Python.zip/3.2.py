import numpy as np
arr=np.array([1,3,2,3,4,2,1,5])
print("Max:",np.max(arr))
print("Min:",np.min(arr))
print("Argmax:",np.argmax(arr))
print("Argmin:",np.argmin(arr))
print("Unique:",np.unique(arr))
print("Bincount:",np.bincount(arr))

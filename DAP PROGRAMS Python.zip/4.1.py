import pandas as pd
data = [18,45,7,33,17,333]
series = pd.Series(data)
print(series)

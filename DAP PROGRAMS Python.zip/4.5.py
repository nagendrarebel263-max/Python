dtypes = df.dtypes
dtypes

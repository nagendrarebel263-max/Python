w=float(input("Enter weight in kilograms "))
Enter weight in kilograms 5.0
pounds=2.205*w
print(f"{w} in pounds are {pounds}")

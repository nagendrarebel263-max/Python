S = "Programming in python is Easy"
C = list(S)
print(C)
